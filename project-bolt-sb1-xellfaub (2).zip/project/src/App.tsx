import React, { useState } from 'react';
import { ClipboardCheck, Car, User, FileCheck, Download, Search, AlertTriangle, CheckCircle } from 'lucide-react';
import * as XLSX from 'xlsx';

interface Inspection {
  id: string;
  driverName: string;
  cnh: string;
  cnhCategory: string;
  cnhExpiration: string;
  tdsExpiration: string;
  vehiclePlate: string;
  vehicleBrand: string;
  fleet?: string;
  vehicleType: 'terceiro' | 'frota' | 'particular';
  vehicleWeight: 'leve' | 'pesado';
  status: 'TUDO OK' | 'QRU';
  inspector: string;
  shift: 'A' | 'B' | 'C';
  date: string;
}

function App() {
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    driverName: '',
    cnh: '',
    cnhCategory: '',
    cnhExpiration: '',
    tdsExpiration: '',
    vehiclePlate: '',
    vehicleBrand: '',
    fleet: '',
    vehicleType: 'terceiro',
    vehicleWeight: 'leve',
    status: 'TUDO OK',
    inspector: '',
    shift: 'A'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newInspection: Inspection = {
      id: Date.now().toString(),
      ...formData,
      date: new Date().toLocaleDateString('pt-BR')
    };
    setInspections([...inspections, newInspection]);
    setFormData({
      driverName: '',
      cnh: '',
      cnhCategory: '',
      cnhExpiration: '',
      tdsExpiration: '',
      vehiclePlate: '',
      vehicleBrand: '',
      fleet: '',
      vehicleType: 'terceiro',
      vehicleWeight: 'leve',
      status: 'TUDO OK',
      inspector: '',
      shift: 'A'
    });
  };

  const getStats = () => {
    const today = new Date().toLocaleDateString('pt-BR');

    const byType = {
      terceiro: {
        total: inspections.filter(i => i.vehicleType === 'terceiro').length,
        ok: inspections.filter(i => i.vehicleType === 'terceiro' && i.status === 'TUDO OK').length,
        qru: inspections.filter(i => i.vehicleType === 'terceiro' && i.status === 'QRU').length
      },
      frota: {
        total: inspections.filter(i => i.vehicleType === 'frota').length,
        ok: inspections.filter(i => i.vehicleType === 'frota' && i.status === 'TUDO OK').length,
        qru: inspections.filter(i => i.vehicleType === 'frota' && i.status === 'QRU').length
      },
      particular: {
        total: inspections.filter(i => i.vehicleType === 'particular').length,
        ok: inspections.filter(i => i.vehicleType === 'particular' && i.status === 'TUDO OK').length,
        qru: inspections.filter(i => i.vehicleType === 'particular' && i.status === 'QRU').length
      }
    };

    const byInspector = inspections.reduce((acc, curr) => {
      const key = `${curr.inspector}-${curr.shift}`;
      acc[key] = acc[key] || { 
        total: 0, 
        ok: 0, 
        qru: 0, 
        shift: curr.shift,
        todayTotal: 0,
        todayOk: 0,
        todayQru: 0
      };
      acc[key].total++;
      if (curr.status === 'TUDO OK') acc[key].ok++;
      else acc[key].qru++;
      
      if (curr.date === today) {
        acc[key].todayTotal++;
        if (curr.status === 'TUDO OK') acc[key].todayOk++;
        else acc[key].todayQru++;
      }
      
      return acc;
    }, {} as Record<string, { 
      total: number; 
      ok: number; 
      qru: number; 
      shift: string;
      todayTotal: number;
      todayOk: number;
      todayQru: number;
    }>);

    return { byType, byInspector };
  };

  const handleExportToExcel = () => {
    const exportData = inspections.map(inspection => ({
      'Data': inspection.date,
      'Condutor': inspection.driverName,
      'CNH': inspection.cnh,
      'Categoria CNH': inspection.cnhCategory,
      'Vencimento CNH': new Date(inspection.cnhExpiration).toLocaleDateString('pt-BR'),
      'Vencimento TDS': new Date(inspection.tdsExpiration).toLocaleDateString('pt-BR'),
      'Placa': inspection.vehiclePlate,
      'Marca e Modelo': inspection.vehicleBrand,
      'Frota': inspection.fleet || '-',
      'Tipo': inspection.vehicleType,
      'Categoria': inspection.vehicleWeight,
      'Status': inspection.status,
      'Agente': inspection.inspector,
      'Turno': inspection.shift
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Vistorias');
    XLSX.writeFile(wb, 'vistorias.xlsx');
  };

  const filteredInspections = inspections.filter(inspection => 
    inspection.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inspection.vehiclePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inspection.inspector.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = getStats();

  return (
    <div className="min-h-screen bg-purple-50">
      <header className="bg-purple-700 text-white p-6 shadow-lg">
        <div className="container mx-auto flex items-center gap-4">
          <ClipboardCheck size={32} />
          <h1 className="text-2xl font-bold">Sistema de Vistorias - Raízen</h1>
        </div>
      </header>

      <main className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <section className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Car className="text-purple-700" />
              Nova Vistoria
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nome do Condutor</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.driverName}
                    onChange={e => setFormData({...formData, driverName: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">CNH</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.cnh}
                    onChange={e => setFormData({...formData, cnh: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Categoria CNH</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.cnhCategory}
                    onChange={e => setFormData({...formData, cnhCategory: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vencimento CNH</label>
                  <input
                    type="date"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.cnhExpiration}
                    onChange={e => setFormData({...formData, cnhExpiration: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Vencimento TDS</label>
                  <input
                    type="date"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.tdsExpiration}
                    onChange={e => setFormData({...formData, tdsExpiration: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Placa do Veículo</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.vehiclePlate}
                    onChange={e => setFormData({...formData, vehiclePlate: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Marca e Modelo</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.vehicleBrand}
                    onChange={e => setFormData({...formData, vehicleBrand: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Número da Frota</label>
                  <input
                    type="text"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.fleet}
                    onChange={e => setFormData({...formData, fleet: e.target.value})}
                    placeholder="Opcional"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Tipo de Veículo</label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.vehicleType}
                    onChange={e => setFormData({...formData, vehicleType: e.target.value as any})}
                  >
                    <option value="terceiro">Terceiro</option>
                    <option value="frota">Frota</option>
                    <option value="particular">Particular</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Categoria do Veículo</label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.vehicleWeight}
                    onChange={e => setFormData({...formData, vehicleWeight: e.target.value as any})}
                  >
                    <option value="leve">Frota Leve</option>
                    <option value="pesado">Frota Pesada</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Status</label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.status}
                    onChange={e => setFormData({...formData, status: e.target.value as any})}
                  >
                    <option value="TUDO OK">TUDO OK</option>
                    <option value="QRU">QRU</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nome do Agente</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.inspector}
                    onChange={e => setFormData({...formData, inspector: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Turno</label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    value={formData.shift}
                    onChange={e => setFormData({...formData, shift: e.target.value as any})}
                  >
                    <option value="A">Turno A</option>
                    <option value="B">Turno B</option>
                    <option value="C">Turno C</option>
                  </select>
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-purple-700 text-white py-2 px-4 rounded-md hover:bg-purple-800 transition-colors"
              >
                Registrar Vistoria
              </button>
            </form>
          </section>

          <section className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <FileCheck className="text-purple-700" />
                Estatísticas de Vistorias
              </h2>
              <div className="space-y-4">
                {Object.entries(stats.byType).map(([type, data]) => (
                  <div key={type} className="bg-purple-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-700 capitalize">{type}</h3>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div>
                        <p className="text-sm text-gray-600">Total</p>
                        <p className="text-lg font-bold text-purple-700">{data.total}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">TUDO OK</p>
                        <p className="text-lg font-bold text-green-600">{data.ok}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">QRU</p>
                        <p className="text-lg font-bold text-red-600">{data.qru}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <User className="text-purple-700" />
                Estatísticas por Agente
              </h2>
              <div className="space-y-4">
                {Object.entries(stats.byInspector).map(([key, data]) => {
                  const [inspector] = key.split('-');
                  return (
                    <div key={key} className="bg-purple-50 p-4 rounded-lg">
                      <h3 className="font-medium text-gray-700">
                        {inspector} - Turno {data.shift}
                      </h3>
                      <div className="grid grid-cols-2 gap-4 mt-2">
                        <div className="bg-white p-3 rounded-lg">
                          <h4 className="text-sm font-medium text-purple-700 mb-2">Total Geral</h4>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <p className="text-xs text-gray-600">Total</p>
                              <p className="text-lg font-bold text-purple-700">{data.total}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">TUDO OK</p>
                              <p className="text-lg font-bold text-green-600">{data.ok}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">QRU</p>
                              <p className="text-lg font-bold text-red-600">{data.qru}</p>
                            </div>
                          </div>
                        </div>
                        <div className="bg-white p-3 rounded-lg">
                          <h4 className="text-sm font-medium text-purple-700 mb-2">Hoje</h4>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <p className="text-xs text-gray-600">Total</p>
                              <p className="text-lg font-bold text-purple-700">{data.todayTotal}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">TUDO OK</p>
                              <p className="text-lg font-bold text-green-600">{data.todayOk}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">QRU</p>
                              <p className="text-lg font-bold text-red-600">{data.todayQru}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>
        </div>

        <section className="mt-6 bg-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Histórico de Vistorias</h2>
            <div className="flex gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Pesquisar..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button
                onClick={handleExportToExcel}
                className="flex items-center gap-2 bg-purple-700 text-white px-4 py-2 rounded-md hover:bg-purple-800 transition-colors"
              >
                <Download size={20} />
                Exportar Excel
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-purple-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Condutor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CNH / Venc.</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">TDS Venc.</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Placa</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marca e Modelo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frota</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoria</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Agente/Turno</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredInspections.map((inspection) => (
                  <tr key={inspection.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{inspection.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{inspection.driverName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {inspection.cnh} ({inspection.cnhCategory}) <br />
                      <span className="text-xs">Venc: {new Date(inspection.cnhExpiration).toLocaleDateString('pt-BR')}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(inspection.tdsExpiration).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{inspection.vehiclePlate}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{inspection.vehicleBrand}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{inspection.fleet || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{inspection.vehicleType}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{inspection.vehicleWeight}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        inspection.status === 'TUDO OK' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {inspection.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {inspection.inspector} <br />
                      <span className="text-xs">Turno {inspection.shift}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;